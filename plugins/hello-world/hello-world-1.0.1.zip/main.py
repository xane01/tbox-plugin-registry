def run(args=None):
    print("Hello from the TBOX plugin registry!")
    print("Plugin version: 1.0.1")
    print("Package update test: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(run())
